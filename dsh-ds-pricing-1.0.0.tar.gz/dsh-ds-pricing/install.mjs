#!/usr/bin/env node
/**
 * dsh-ds-pricing — 一键安装器。
 *
 * 做三件事（全部可重入，重复运行只补齐缺的部分）：
 *   1. 把插件目录自身复制到 $DSH_HOME/plugins/<name>（如果它已经在那个位置就跳过）；
 *   2. 在当前 profile 的 package.json 里登记 dependencies + dsh.profile.bundles；
 *   3. 在 profile 的 node_modules 里建一个指向插件目录的链接。
 *
 * 不做的事：不跑 npm install（本地 file: 依赖只要清单 + 链接即可），不动全局配置，
 * 不写任何 token，不修改别的插件。
 *
 * 用法：
 *   node install.mjs                 # 自动挑 profile（只有一个就选它）
 *   node install.mjs --profile dev   # 指定 profile 名
 *   node install.mjs --dry-run       # 只说要做什么
 *   node install.mjs --uninstall     # 反向操作（保留插件目录本身）
 */
import {
  cpSync,
  existsSync,
  lstatSync,
  mkdirSync,
  readFileSync,
  readdirSync,
  realpathSync,
  rmSync,
  symlinkSync,
  unlinkSync,
  writeFileSync,
} from 'node:fs'
import { homedir } from 'node:os'
import { dirname, join, relative, resolve, sep } from 'node:path'
import { fileURLToPath } from 'node:url'

const HERE = dirname(fileURLToPath(import.meta.url))
const PKG = JSON.parse(readFileSync(join(HERE, 'package.json'), 'utf8'))
const NAME = PKG.name
const VERSION = PKG.version

const argv = process.argv.slice(2)
const has = flag => argv.includes(flag)
const valueOf = flag => {
  const i = argv.indexOf(flag)
  return i === -1 ? undefined : argv[i + 1]
}
const DRY = has('--dry-run')
const UNINSTALL = has('--uninstall')
const PROFILE_ARG = valueOf('--profile')

const DSH_HOME = process.env.DSH_HOME ? resolve(process.env.DSH_HOME) : join(homedir(), '.dsh')
const PLUGINS_DIR = join(DSH_HOME, 'plugins')
const TARGET = join(PLUGINS_DIR, NAME)

const log = message => console.log(message)
const act = message => console.log(DRY ? `[dry-run] ${message}` : message)

function die(message) {
  console.error(`\n✗ ${message}`)
  process.exit(1)
}

// ── 1. profile 定位 ────────────────────────────────────────────────────────
function pickProfile() {
  const profilesDir = join(DSH_HOME, 'profiles')
  if (!existsSync(profilesDir)) {
    die(`找不到 ${profilesDir}。确认 DSH_HOME 是否正确（当前 ${DSH_HOME}），或用 DSH_HOME=/path/to/.dsh 重跑。`)
  }
  const dirs = readdirSafe(profilesDir)
  if (PROFILE_ARG) {
    if (!dirs.includes(PROFILE_ARG)) die(`profile "${PROFILE_ARG}" 不存在。现有：${dirs.join(', ') || '（无）'}`)
    return join(profilesDir, PROFILE_ARG)
  }
  if (process.env.DSH_PROFILE && dirs.includes(process.env.DSH_PROFILE)) {
    return join(profilesDir, process.env.DSH_PROFILE)
  }
  if (dirs.length === 1) return join(profilesDir, dirs[0])
  if (dirs.length === 0) die(`profiles 目录是空的：${profilesDir}`)
  die(`有多个 profile：${dirs.join(', ')}。用 --profile <名字> 指定要装进哪个。`)
}

function readdirSafe(path) {
  try {
    return readdirSync(path, { withFileTypes: true })
      .filter(entry => entry.isDirectory() || entry.isSymbolicLink())
      .map(entry => entry.name)
  } catch {
    return []
  }
}

const profileDir = pickProfile()
const manifestPath = join(profileDir, 'package.json')
if (!existsSync(manifestPath)) die(`${manifestPath} 不存在 —— 这不是一个 dsh profile 目录。`)

// ── 2. 复制插件到 $DSH_HOME/plugins/<name> ──────────────────────────────────
function samePath(a, b) {
  try {
    return realpathSync(a) === realpathSync(b)
  } catch {
    return false
  }
}

function copySelf() {
  mkdirSync(PLUGINS_DIR, { recursive: true })
  if (samePath(HERE, TARGET)) {
    log(`• 插件已就位：${TARGET}`)
    return
  }
  act(`• 复制插件：${HERE} → ${TARGET}`)
  if (DRY) return
  rmSync(TARGET, { recursive: true, force: true })
  cpSync(HERE, TARGET, {
    recursive: true,
    filter: source => !/[\\/](node_modules|\.git)([\\/]|$)/.test(source),
  })
}

// ── 3. 改 profile 清单 ────────────────────────────────────────────────────
function editManifest() {
  const raw = readFileSync(manifestPath, 'utf8')
  const pkg = JSON.parse(raw)
  const spec = `file:../../plugins/${NAME}`
  let changed = false

  pkg.dependencies = pkg.dependencies ?? {}
  if (UNINSTALL) {
    if (pkg.dependencies[NAME] !== undefined) {
      delete pkg.dependencies[NAME]
      changed = true
      act(`• dependencies 移除 ${NAME}`)
    }
  } else if (pkg.dependencies[NAME] !== spec) {
    pkg.dependencies[NAME] = spec
    changed = true
    act(`• dependencies += "${NAME}": "${spec}"`)
  } else {
    log(`• dependencies 已含 ${NAME}`)
  }

  pkg.dsh = pkg.dsh ?? {}
  pkg.dsh.profile = pkg.dsh.profile ?? {}
  const bundles = Array.isArray(pkg.dsh.profile.bundles) ? pkg.dsh.profile.bundles.slice() : []
  const at = bundles.indexOf(NAME)

  if (UNINSTALL) {
    if (at !== -1) {
      bundles.splice(at, 1)
      changed = true
      act(`• bundles 移除 ${NAME}`)
    }
  } else if (at === -1) {
    // 插在 web-app 之后（其它 bundle 之前）：host 半身是空插件，位置只影响 patch
    // 层顺序，放前面最安全。
    const anchor = bundles.indexOf('@deepseek-ai/dsh-web-app')
    const index = anchor === -1 ? bundles.length : anchor + 1
    bundles.splice(index, 0, NAME)
    changed = true
    act(`• bundles 插入 ${NAME}（第 ${index + 1} 位）`)
  } else {
    log(`• bundles 已含 ${NAME}（第 ${at + 1} 位）`)
  }
  pkg.dsh.profile.bundles = bundles

  if (!changed) return
  if (DRY) return
  const backup = `${manifestPath}.bak-${NAME}`
  if (!existsSync(backup)) writeFileSync(backup, raw)
  writeFileSync(manifestPath, JSON.stringify(pkg, null, 2) + '\n')
}

// ── 4. node_modules 链接 ───────────────────────────────────────────────────
function linkPackage() {
  const modulesDir = join(profileDir, 'node_modules')
  const linkPath = join(modulesDir, NAME)
  mkdirSync(modulesDir, { recursive: true })

  if (UNINSTALL) {
    if (existsSync(linkPath) || isLink(linkPath)) {
      act(`• 移除链接 ${linkPath}`)
      if (!DRY) removeEntry(linkPath)
    }
    return
  }

  const target = relative(modulesDir, TARGET) || '.'
  const wanted = resolveLink(TARGET) || resolve(TARGET)
  if (isLink(linkPath)) {
    if (resolveLink(linkPath) === wanted) {
      log(`• 链接已就位：node_modules/${NAME} → ${target}`)
      return
    }
    act(`• 重建链接：node_modules/${NAME} → ${target}`)
    if (!DRY) removeEntry(linkPath)
  } else if (existsSync(linkPath)) {
    act(`• node_modules/${NAME} 是真实目录，替换为链接`)
    if (!DRY) removeEntry(linkPath)
  } else {
    act(`• 建链接：node_modules/${NAME} → ${target}`)
  }
  if (DRY) return
  try {
    // Windows 目录链接要走 junction，且目标必须是绝对路径。
    if (process.platform === 'win32') symlinkSync(TARGET, linkPath, 'junction')
    else symlinkSync(target, linkPath, 'dir')
  } catch (error) {
    // 没有权限建链接时退化成拷贝 —— 可运行，只是后续改插件要重装。
    console.warn(`! 建链接失败（${error.code || error.message}），改为复制目录。`)
    cpSync(TARGET, linkPath, { recursive: true })
  }
}

function isLink(path) {
  try {
    return lstatSync(path).isSymbolicLink()
  } catch {
    return false
  }
}

function resolveLink(path) {
  try {
    return realpathSync(path)
  } catch {
    return ''
  }
}

function removeEntry(path) {
  try {
    lstatSync(path)
  } catch {
    return
  }
  rmSync(path, { recursive: true, force: true })
}

// ── 收尾 ─────────────────────────────────────────────────────────────────
copySelf()
editManifest()
linkPackage()

const profileName = profileDir.split(sep).pop()
if (UNINSTALL) {
  log(`\n✓ 已从 profile "${profileName}" 卸载 ${NAME}。重启 DSH 后徽标消失。`)
} else {
  log(`\n✓ ${NAME}@${VERSION} 已接入 profile "${profileName}"`)
  log(`  插件目录：${TARGET}`)
  log('  下一步：完全退出并重启 DSH（只是刷新页面不够，新 bundle 要重读 profile 组合）。')
  log('  生效标志：在任意已有会话里，输入卡正上方出现「峰价/谷价 · 忙时/闲时」小胶囊。')
}
