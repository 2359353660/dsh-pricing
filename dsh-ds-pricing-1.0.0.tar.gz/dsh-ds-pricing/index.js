/**
 * dsh-ds-pricing — plugin entry (Host half).
 *
 * The plugin is a browser-only feature: a peak/off-peak price badge above the
 * composer. The host half intentionally does nothing, but it must exist and be
 * an importable cordis plugin, because the client-modules server only serves a
 * client bundle for packages that own a live loader entry (see the `dsh.client`
 * block in package.json and the insert row in cordis.patch.yml).
 *
 * @module index.js
 */

export const name = 'ds-pricing'

export const version = '1.0.0'

/** No host-side services, no configuration. */
export function apply() {}
