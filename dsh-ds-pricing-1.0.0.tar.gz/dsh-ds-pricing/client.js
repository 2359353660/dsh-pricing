/**
 * dsh-ds-pricing — browser half.
 *
 * Contributes exactly one thing to the web shell: a small pill above the
 * composer card (`conversation.input.dock`) that reads the local clock, decides
 * whether DeepSeek's API is currently billing peak or off-peak, and shows which
 * one it is. Clicking it opens the per-model price table (off-peak vs peak) for
 * the model actually selected in this session.
 *
 * Why the composer dock: `conversation.input.dock` is the documented list slot
 * rendered immediately above the input card, so the badge sits at the top of the
 * conversation box, outside the text field, and survives every transcript
 * re-render. It is session-scoped, which is exactly what the model projection
 * (`modelSelection`) needs.
 *
 * Everything is derived from two authorities, both cited in the panel:
 *   - billing windows: DeepSeek API docs, "模型 & 价格" — peak = Beijing time
 *     Mon–Fri 09:00–12:00 and 14:00–18:00, legal holidays excluded; everything
 *     else (including all weekend hours and whole legal holidays) is off-peak,
 *     priced at half the peak rate.
 *   - holiday calendar: 国务院办公厅 2026 / 2027 放假安排 (only the off-days that
 *     fall on a weekday matter — weekends are off-peak regardless).
 *
 * Hand-written ModuleLoader bundle: no build step, no dependency beyond the
 * `react` the shell already provides. All colour comes from theme variables, so
 * the badge survives a light/dark switch.
 */
window.__ModuleLoader__.load({
  id: 'dsh-ds-pricing',
  factory: require => {
    const module = { exports: {} }
    const exports = module.exports
    const React = require('react')
    const { createElement: h, useState, useEffect, useRef } = React

    const NS = 'dsPricing'
    const inject = ['slots', 'locale']

    const PRICING_URL = 'https://api-docs.deepseek.com/zh-cn/quick_start/pricing/'

    /**
     * Official list prices, 元 per million tokens, as `[rowKey, offPeak, peak]`.
     * Source: DeepSeek API docs / 模型 & 价格 (read 2026-11-09). Off-peak is
     * exactly half of peak, which is why the badge can also be trusted for a
     * model whose exact numbers have not been transcribed here.
     */
    const PRICES = {
      'deepseek-flash': [
        ['row.hit', 0.02, 0.04],
        ['row.miss', 1, 2],
        ['row.out', 4, 8],
      ],
      'deepseek-v4-pro': [
        ['row.hit', 0.15, 0.3],
        ['row.miss', 4.5, 9],
        ['row.out', 13.5, 27],
      ],
    }

    /** Row labels for a model whose prices are not in PRICES. */
    const UNKNOWN_ROWS = [
      ['row.hit', null, null],
      ['row.miss', null, null],
      ['row.out', null, null],
    ]

    /**
     * Weekday legal holidays (full-day off-peak). Weekend dates are omitted on
     * purpose: weekends are off-peak by the billing rule itself, so only a
     * holiday falling on Mon–Fri can change the answer.
     *
     * 2026 / 2027 both come from 国办发明电 notices via the holiday-cn dataset.
     */
    const OFF_DAYS = {
      
      // 2026
      '2026-01-01': '元旦',
      '2026-01-02': '元旦',
      '2026-02-16': '春节',
      '2026-02-17': '春节',
      '2026-02-18': '春节',
      '2026-02-19': '春节',
      '2026-02-20': '春节',
      '2026-02-23': '春节',
      '2026-04-06': '清明节',
      '2026-05-01': '劳动节',
      '2026-05-04': '劳动节',
      '2026-05-05': '劳动节',
      '2026-06-19': '端午节',
      '2026-09-25': '中秋节',
      '2026-10-01': '国庆节',
      '2026-10-02': '国庆节',
      '2026-10-05': '国庆节',
      '2026-10-06': '国庆节',
      '2026-10-07': '国庆节',
      // 2027
      '2027-01-01': '元旦',
      '2027-02-05': '春节',
      '2027-02-08': '春节',
      '2027-02-09': '春节',
      '2027-02-10': '春节',
      '2027-02-11': '春节',
      '2027-02-12': '春节',
      '2027-04-05': '清明节',
      '2027-05-03': '劳动节',
      '2027-05-04': '劳动节',
      '2027-05-05': '劳动节',
      '2027-06-09': '端午节',
      '2027-09-15': '中秋节',
      '2027-10-01': '国庆节',
      '2027-10-04': '国庆节',
      '2027-10-05': '国庆节',
      '2027-10-06': '国庆节',
      '2027-10-07': '国庆节',
    
    }

    const DICT = {
      zh: {
        'badge.peak': '峰价',
        'badge.valley': '谷价',
        'badge.busy': '忙时',
        'badge.idle': '闲时',
        'badge.untilPeak': '距高峰',
        'badge.untilValley': '距谷时',
        'panel.title': 'DeepSeek 峰谷价',
        'panel.current': '当前',
        'panel.col.off': '谷价',
        'panel.col.peak': '峰价',
        'panel.unit': '元 / 百万 tokens',
        'row.hit': '输入 · 缓存命中',
        'row.miss': '输入 · 缓存未命中',
        'row.out': '输出',
        'panel.next': '下次切换',
        'panel.toPeak': '转入高峰',
        'panel.toOff': '转入空闲',
        'panel.rule':
          '高峰：北京时间周一至周五 9:00–12:00、14:00–18:00（法定节假日除外）；其余时段与周末、法定节假日全天空闲。谷价 = 峰价 × 50%。',
        'panel.unknown': '该模型单价未收录，峰价通常为谷价的 2 倍，具体见官方定价页。',
        'panel.official': '官方定价页',
        'reason.weekend': '周末 · 全天空闲',
        'reason.holiday': '{name}假期 · 全天空闲',
        'reason.morning': '高峰时段 · 09:00–12:00',
        'reason.afternoon': '高峰时段 · 14:00–18:00',
        'reason.early': '工作日 9 点前 · 空闲',
        'reason.noon': '午间空闲 · 12:00–14:00',
        'reason.evening': '18 点后 · 夜间空闲',
      },
      en: {
        'badge.peak': 'Peak',
        'badge.valley': 'Off-peak',
        'badge.busy': 'peak hours',
        'badge.idle': 'off-peak',
        'badge.untilPeak': 'peak in',
        'badge.untilValley': 'off-peak in',
        'panel.title': 'DeepSeek peak / off-peak',
        'panel.current': 'now',
        'panel.col.off': 'Off-peak',
        'panel.col.peak': 'Peak',
        'panel.unit': 'CNY / 1M tokens',
        'row.hit': 'Input · cache hit',
        'row.miss': 'Input · cache miss',
        'row.out': 'Output',
        'panel.next': 'Next change',
        'panel.toPeak': 'to peak',
        'panel.toOff': 'to off-peak',
        'panel.rule':
          'Peak: Beijing time Mon–Fri 09:00–12:00 and 14:00–18:00, excluding Chinese legal holidays. Everything else — nights, weekends and whole holidays — is off-peak, at half the peak rate.',
        'panel.unknown': 'Unit prices for this model are not transcribed here; peak is normally 2× off-peak. See the official price page.',
        'panel.official': 'Official pricing',
        'reason.weekend': 'weekend · off-peak all day',
        'reason.holiday': '{name} holiday · off-peak all day',
        'reason.morning': 'peak · 09:00–12:00',
        'reason.afternoon': 'peak · 14:00–18:00',
        'reason.early': 'before 09:00 on a workday · off-peak',
        'reason.noon': 'midday break · 12:00–14:00 · off-peak',
        'reason.evening': 'after 18:00 · night · off-peak',
      },
    }

    // ── Beijing clock ────────────────────────────────────────────────────────
    //
    // Every window in the billing rule is Beijing time, so the decision is made
    // on Beijing wall-clock parts, never on the machine's own zone. China has no
    // DST, so a fixed +08:00 offset is exact and lets date arithmetic stay in
    // UTC milliseconds.
    const BJ_OFFSET_MS = 8 * 3600 * 1000
    const BJ_FMT = new Intl.DateTimeFormat('en-GB', {
      timeZone: 'Asia/Shanghai',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hourCycle: 'h23',
    })

    const pad = n => (n < 10 ? '0' + String(n) : String(n))

    /** Beijing calendar/clock parts for an epoch millisecond. */
    function bjParts(ms) {
      const out = {}
      const parts = BJ_FMT.formatToParts(new Date(ms))
      for (let i = 0; i < parts.length; i += 1) {
        const part = parts[i]
        if (part.type !== 'literal') out[part.type] = part.value
      }
      const y = Number(out.year)
      const mo = Number(out.month)
      const d = Number(out.day)
      const hh = Number(out.hour) % 24
      const mi = Number(out.minute)
      const ss = Number(out.second)
      return {
        y,
        mo,
        d,
        hh,
        mi,
        ss,
        key: String(y) + '-' + pad(mo) + '-' + pad(d),
        weekday: new Date(Date.UTC(y, mo - 1, d)).getUTCDay(),
        minutes: hh * 60 + mi,
        clock: pad(hh) + ':' + pad(mi),
      }
    }

    /** Epoch ms for a Beijing wall-clock hour on the day `baseUtc` starts. */
    function bjInstant(dayStartUtc, hour, minute) {
      return dayStartUtc + hour * 3600000 + (minute || 0) * 60000 - BJ_OFFSET_MS
    }

    /**
     * Billing state at one instant.
     * @returns {{ peak: boolean, reasonKey: string, reasonName: string, holiday?: string, clock: string, key: string }}
     */
    function priceState(ms) {
      const p = bjParts(ms)
      const holiday = OFF_DAYS[p.key]
      const weekend = p.weekday === 0 || p.weekday === 6
      const morning = p.minutes >= 540 && p.minutes < 720
      const afternoon = p.minutes >= 840 && p.minutes < 1080
      const peak = !weekend && holiday === undefined && (morning || afternoon)
      let reasonKey = 'reason.evening'
      if (holiday !== undefined) reasonKey = 'reason.holiday'
      else if (weekend) reasonKey = 'reason.weekend'
      else if (morning) reasonKey = 'reason.morning'
      else if (afternoon) reasonKey = 'reason.afternoon'
      else if (p.minutes < 540) reasonKey = 'reason.early'
      else if (p.minutes < 840) reasonKey = 'reason.noon'
      return { peak, reasonKey, holiday, weekend, clock: p.clock, key: p.key }
    }

    /**
     * First instant strictly after `now` where the peak flag flips. The flag can
     * only change at a day boundary (holiday/weekend) or at one of the four
     * window edges, so those candidates are enough — no minute scan.
     */
    function nextSwitch(now) {
      const current = priceState(now)
      const p = bjParts(now)
      const dayStart = Date.UTC(p.y, p.mo - 1, p.d)
      const edges = [0, 9, 12, 14, 18]
      for (let day = 0; day < 14; day += 1) {
        for (let i = 0; i < edges.length; i += 1) {
          const at = bjInstant(dayStart + day * 86400000, edges[i], 0)
          if (at <= now) continue
          const state = priceState(at)
          if (state.peak !== current.peak) return { at, state }
        }
      }
      return undefined
    }

    /** Compact gap: `13h`, `1h20m`, `12m`. */
    function shortGap(ms) {
      const total = Math.max(0, Math.round(ms / 60000))
      const days = Math.floor(total / 1440)
      const hours = Math.floor((total % 1440) / 60)
      const mins = total % 60
      if (days > 0) return String(days) + 'd ' + String(hours) + 'h'
      if (hours > 0) return mins === 0 ? String(hours) + 'h' : String(hours) + 'h' + pad(mins) + 'm'
      return String(mins) + 'm'
    }

    /** Absolute target: `今天 14:00`, `明天 09:00`, `周三 09:00`, `1/1 09:00`. */
    function whenText(at, now) {
      const a = bjParts(at)
      const n = bjParts(now)
      const dayDiff = Math.round((Date.UTC(a.y, a.mo - 1, a.d) - Date.UTC(n.y, n.mo - 1, n.d)) / 86400000)
      const hhmm = pad(a.hh) + ':' + pad(a.mi)
      return { a, n, dayDiff, hhmm }
    }

    function whenLabel(at, now, zh) {
      const { a, dayDiff, hhmm } = whenText(at, now)
      const week = zh
        ? ['周日', '周一', '周二', '周三', '周四', '周五', '周六'][a.weekday]
        : ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'][a.weekday]
      if (dayDiff === 0) return (zh ? '今天 ' : 'today ') + hhmm
      if (dayDiff === 1) return (zh ? '明天 ' : 'tomorrow ') + hhmm
      if (dayDiff < 7) return week + ' ' + hhmm
      return String(a.mo) + '/' + String(a.d) + ' ' + hhmm
    }

    // ── model → price table ──────────────────────────────────────────────────
    //
    // Only DeepSeek's own provider routes bill at these rates: `deepseek-account`
    // (account login) and `deepseek-official` (API key). A DeepSeek model reached
    // through a third-party or aggregator plugin bills at that plugin's own rate,
    // which this badge must not claim to know, so the provider prefix decides.
    function dsSelection(selection) {
      const pick = selection && (selection.next || selection.lastUsed)
      if (!pick) return undefined
      const provider = typeof pick.provider === 'string' ? pick.provider : ''
      const model = typeof pick.model === 'string' ? pick.model : ''
      if (!provider || !model) return undefined
      if (!/^deepseek/i.test(provider)) return undefined
      return { provider, model }
    }

    function tableFor(model) {
      const id = String(model || '').toLowerCase()
      if (id.indexOf('pro') !== -1 && PRICES['deepseek-v4-pro']) return PRICES['deepseek-v4-pro']
      if (id.indexOf('flash') !== -1) return PRICES['deepseek-flash']
      if (id.indexOf('chat') !== -1 || id.indexOf('reasoner') !== -1) return PRICES['deepseek-flash']
      return undefined
    }

    // ── styles ───────────────────────────────────────────────────────────────
    const CSS = `
.dsp-root{position:relative;align-self:center;box-sizing:border-box;display:flex;justify-content:flex-start;width:min(calc(var(--dsh-composer-card-max-width,760px)),100%)}
.dsp-badge{--dsp-accent:#059669;display:inline-flex;align-items:center;gap:6px;box-sizing:border-box;max-width:100%;height:22px;padding:0 9px;border-radius:999px;border:.5px solid var(--dsw-alias-border-l1,rgba(127,127,127,.3));background:color-mix(in srgb,var(--dsp-accent) 10%,transparent);color:var(--dsw-alias-label-secondary,#666);font-size:12px;line-height:16px;font-family:inherit;white-space:nowrap;cursor:pointer;transition:background .15s ease,border-color .15s ease}
.dsp-badge[data-state=peak]{--dsp-accent:#d97706}
.dsp-badge:hover{background:color-mix(in srgb,var(--dsp-accent) 18%,transparent);border-color:color-mix(in srgb,var(--dsp-accent) 45%,transparent)}
.dsp-badge:focus-visible{outline:2px solid color-mix(in srgb,var(--dsp-accent) 55%,transparent);outline-offset:2px}
.dsp-dot{flex:none;width:6px;height:6px;border-radius:50%;background:var(--dsp-accent);box-shadow:0 0 0 3px color-mix(in srgb,var(--dsp-accent) 16%,transparent)}
.dsp-label{font-weight:600;color:var(--dsp-accent)}
.dsp-sep,.dsp-mode{color:var(--dsw-alias-label-tertiary,#8a8a8a)}
.dsp-gap{margin-left:4px;padding-left:8px;border-left:.5px solid var(--dsw-alias-border-l1,rgba(127,127,127,.3));color:var(--dsw-alias-label-tertiary,#8a8a8a);font-variant-numeric:tabular-nums}
.dsp-panel{position:absolute;left:0;bottom:calc(100% + 8px);z-index:40;box-sizing:border-box;width:336px;max-width:calc(100vw - 40px);padding:11px 13px 12px;border-radius:var(--dsw-radius-lg,12px);border:.5px solid var(--dsw-alias-border-l1,rgba(127,127,127,.3));background:var(--dsw-specific-menu,var(--dsw-alias-bg-elevated,#fff));box-shadow:var(--dsw-elevation-panel,0 12px 32px rgba(0,0,0,.18));color:var(--dsw-alias-label-primary,#111);font-size:12px;line-height:18px}
.dsp-head{display:flex;align-items:center;gap:8px}
.dsp-title{font-size:13px;font-weight:600}
.dsp-chip{margin-left:auto;padding:1px 7px;border-radius:999px;font-size:11px;line-height:16px;color:#059669;background:color-mix(in srgb,#059669 12%,transparent)}
.dsp-chip[data-state=peak]{color:#d97706;background:color-mix(in srgb,#d97706 14%,transparent)}
.dsp-sub{margin-top:3px;color:var(--dsw-alias-label-tertiary,#8a8a8a);font-size:11px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.dsp-table{margin-top:9px;border:.5px solid var(--dsw-alias-border-l1,rgba(127,127,127,.22));border-radius:var(--dsw-radius-md,8px);overflow:hidden}
.dsp-tr{display:grid;grid-template-columns:minmax(0,1fr) 68px 68px;align-items:center}
.dsp-tr+.dsp-tr{border-top:.5px solid var(--dsw-alias-border-l1,rgba(127,127,127,.16))}
.dsp-th,.dsp-td{padding:4px 8px;font-variant-numeric:tabular-nums}
.dsp-th{font-size:11px;font-weight:500;text-align:right;color:var(--dsw-alias-label-tertiary,#8a8a8a);background:color-mix(in srgb,var(--dsw-alias-label-primary,#111) 4%,transparent)}
.dsp-th:first-child{text-align:left}
.dsp-td{text-align:right;color:var(--dsw-alias-label-secondary,#666)}
.dsp-tdLabel{text-align:left;color:var(--dsw-alias-label-primary,#111)}
.dsp-thActive,.dsp-tdActive{font-weight:600;color:#059669;background:color-mix(in srgb,#059669 12%,transparent)}
.dsp-root[data-ds-pricing=peak] .dsp-thActive,.dsp-root[data-ds-pricing=peak] .dsp-tdActive{color:#d97706;background:color-mix(in srgb,#d97706 14%,transparent)}
.dsp-unit{margin-top:6px;text-align:right;color:var(--dsw-alias-label-tertiary,#8a8a8a);font-size:11px}
.dsp-next{margin-top:8px;color:var(--dsw-alias-label-secondary,#666)}
.dsp-note{margin-top:6px;color:var(--dsw-alias-label-tertiary,#8a8a8a);font-size:11px;line-height:16px}
.dsp-link{display:inline-block;margin-top:6px;font-size:11px;color:var(--dsw-alias-state-business-primary,#3b6cff);text-decoration:none}
.dsp-link:hover{text-decoration:underline}
`

    // ── component ────────────────────────────────────────────────────────────

    /**
     * The dock item: badge + popover.
     *
     * Hooks run unconditionally (rules of hooks); the component returns null for
     * every non-DeepSeek model, and its ticking timer only exists while the badge
     * is actually shown.
     */
    function DsPricingDock(props) {
      const useProjection = props.useProjection
      const rawT = props.t
      const t = typeof rawT === 'function' ? rawT : key => key
      const zh = typeof props.locale === 'string' ? props.locale.indexOf('zh') === 0 : true
      const selection = useProjection('modelSelection')
      const ds = dsSelection(selection)
      const active = ds !== undefined
      const [open, setOpen] = useState(false)
      const [now, setNow] = useState(() => Date.now())
      const wrap = useRef(null)

      useEffect(() => {
        if (!active) return undefined
        const id = setInterval(() => setNow(Date.now()), 1000)
        return () => clearInterval(id)
      }, [active])

      useEffect(() => {
        if (!open) return undefined
        const onDown = event => {
          const el = wrap.current
          const target = event.target
          if (el && target && typeof el.contains === 'function' && el.contains(target)) return
          setOpen(false)
        }
        const onKey = event => {
          if (event.key === 'Escape') setOpen(false)
        }
        document.addEventListener('mousedown', onDown, true)
        document.addEventListener('keydown', onKey, true)
        return () => {
          document.removeEventListener('mousedown', onDown, true)
          document.removeEventListener('keydown', onKey, true)
        }
      }, [open])

      if (!active) return null

      const state = priceState(now)
      const next = nextSwitch(now)
      const rows = tableFor(ds.model) || UNKNOWN_ROWS
      const known = tableFor(ds.model) !== undefined
      const label = state.peak ? t('badge.peak') : t('badge.valley')
      const mode = state.peak ? t('badge.busy') : t('badge.idle')
      const reason = t(state.reasonKey).replace('{name}', state.holiday || '')

      const badgeChildren = [
        h('span', { key: 'dot', className: 'dsp-dot' }),
        h('span', { key: 'label', className: 'dsp-label' }, label),
        h('span', { key: 'sep', className: 'dsp-sep' }, '·'),
        h('span', { key: 'mode', className: 'dsp-mode' }, mode),
      ]
      if (next) {
        badgeChildren.push(
          h(
            'span',
            { key: 'gap', className: 'dsp-gap' },
            (state.peak ? t('badge.untilValley') : t('badge.untilPeak')) + ' ' + shortGap(next.at - now),
          ),
        )
      }

      const headerCells = [
        h('span', { key: 'label', className: 'dsp-th' }, ''),
        h('span', { key: 'off', className: 'dsp-th' + (state.peak ? '' : ' dsp-thActive') }, t('panel.col.off')),
        h('span', { key: 'peak', className: 'dsp-th' + (state.peak ? ' dsp-thActive' : '') }, t('panel.col.peak')),
      ]

      const bodyRows = rows.map(row => {
        const key = row[0]
        const off = row[1]
        const peak = row[2]
        return h(
          'div',
          { key, className: 'dsp-tr' },
          h('span', { className: 'dsp-td dsp-tdLabel' }, t(key)),
          h(
            'span',
            { className: 'dsp-td' + (state.peak ? '' : ' dsp-tdActive') },
            off === null || off === undefined ? '—' : String(off),
          ),
          h(
            'span',
            { className: 'dsp-td' + (state.peak ? ' dsp-tdActive' : '') },
            peak === null || peak === undefined ? '—' : String(peak),
          ),
        )
      })

      const panelChildren = [
        h(
          'div',
          { key: 'head', className: 'dsp-head' },
          h('span', { className: 'dsp-title' }, t('panel.title')),
          h('span', { className: 'dsp-chip', 'data-state': state.peak ? 'peak' : 'valley' }, label),
        ),
        h('div', { key: 'sub', className: 'dsp-sub' }, ds.model + ' · ' + reason),
        h('div', { key: 'table', className: 'dsp-table' }, h('div', { className: 'dsp-tr' }, headerCells), bodyRows),
        h('div', { key: 'unit', className: 'dsp-unit' }, t('panel.unit')),
      ]
      if (next) {
        panelChildren.push(
          h(
            'div',
            { key: 'next', className: 'dsp-next' },
            t('panel.next') + ' · ' + whenLabel(next.at, now, zh) + ' ' + (next.state.peak ? t('panel.toPeak') : t('panel.toOff')),
          ),
        )
      }
      if (!known) panelChildren.push(h('div', { key: 'unknown', className: 'dsp-note' }, t('panel.unknown')))
      panelChildren.push(h('div', { key: 'rule', className: 'dsp-note' }, t('panel.rule')))
      panelChildren.push(
        h(
          'a',
          { key: 'link', className: 'dsp-link', href: PRICING_URL, target: '_blank', rel: 'noreferrer noopener' },
          t('panel.official'),
        ),
      )

      return h(
        'div',
        { ref: wrap, className: 'dsp-root', 'data-ds-pricing': state.peak ? 'peak' : 'valley' },
        h(
          'button',
          {
            type: 'button',
            className: 'dsp-badge',
            'data-state': state.peak ? 'peak' : 'valley',
            'data-ds-pricing-badge': '',
            'aria-expanded': open ? 'true' : 'false',
            'aria-label': t('panel.title') + ' ' + label + ' · ' + reason + ' · ' + ds.model,
            title: ds.model + ' · ' + reason,
            onClick: () => setOpen(value => !value),
          },
          badgeChildren,
        ),
        open
          ? h(
              'div',
              { className: 'dsp-panel', role: 'dialog', 'aria-label': t('panel.title'), 'data-ds-pricing-panel': '' },
              panelChildren,
            )
          : null,
      )
    }

    // ── plugin ───────────────────────────────────────────────────────────────

    /**
     * Active language at render time. The shell mirrors it onto <html lang>, and
     * the locale service exposes it directly; either is enough to pick the date
     * wording (今天 / 明天 / 周三 vs today / tomorrow / Wed). Read at render, not
     * at apply, so a language switch does not need a reload.
     */
    function localeTag(ctx) {
      try {
        const snapshot =
          typeof ctx.locale?.getLocale === 'function' ? ctx.locale.getLocale() : ctx.locale?.getSnapshot?.()
        const value = snapshot?.active ?? ctx.locale?.locale
        if (typeof value === 'string' && value !== '') return value
      } catch {
        /* locale face unavailable — fall through to the document language */
      }
      if (typeof document !== 'undefined' && typeof document.documentElement.lang === 'string') {
        return document.documentElement.lang
      }
      return 'zh'
    }

    function apply(ctx) {
      const t = ctx.locale.bind(NS)
      ctx.effect(() => ctx.locale.register(NS, { zh: DICT.zh, en: DICT.en }), 'ds-pricing: dictionaries')

      ctx.effect(() => {
        const style = document.createElement('style')
        style.setAttribute('data-plugin', 'dsh-ds-pricing')
        style.textContent = CSS
        document.head.appendChild(style)
        return () => style.remove()
      }, 'ds-pricing: styles')

      ctx.slots.inject('conversation.input.dock', () =>
        ctx.slots.register(
          {
            name: 'conversation.input.dock',
            id: 'ds-pricing',
            // Negative order keeps the badge above any other dock item (todo
            // panel sits at 0) so it stays the topmost row of the composer stack.
            order: -100,
            locale: NS,
          },
          props => h(DsPricingDock, Object.assign({}, props, { t, locale: localeTag(ctx) })),
        ),
      )
    }

    exports.name = 'ds-pricing'
    exports.inject = inject
    exports.apply = apply
    // Headless seams for the repo's own smoke test (same idea as the other local
    // plugins): pure functions only, no React involved.
    exports.__test = { DsPricingDock, bjParts, priceState, nextSwitch, shortGap, whenLabel, dsSelection, tableFor, OFF_DAYS, PRICES, DICT, CSS }
    return module.exports
  },
})
