# dsh-ds-pricing

在会话输入卡正上方加一枚小胶囊：用 DeepSeek 官方模型时，按**北京时间**判断当前是 **峰价（忙时）** 还是 **谷价（闲时）**；点一下展开该模型的三行单价（输入·缓存命中 / 输入·缓存未命中 / 输出），谷价、峰价并排，当前生效的那一列高亮。

```
[  ● 谷价 · 闲时  距高峰 13h  ]        ← 徽标（conversation.input.dock）
┌───────────────────────────────┐
│  给 DeepSeek 发送消息…          │
└───────────────────────────────┘
```

## 行为

- **什么时候显示**：只在会话绑定到 DeepSeek 官方 provider 时渲染 —— `deepseek-account`（账号登录）或 `deepseek-official`（API key）。DeepSeek 模型经由第三方/聚合插件路由时单价归那家所有，徽标不猜。
- **空白新会话页不显示**：挂载点 `conversation.input.dock` 是 session 作用域的强绑定槽位，没有会话对象时不渲染；发出第一条消息或打开已有会话后出现。
- **判定规则**（官方原文）：北京时间**周一至周五**（不含法定节假日）**9:00–12:00、14:00–18:00** 为高峰，其余时段全部空闲；**周末与法定节假日全天**空闲；谷价 = 峰价 × 50%。
  - 周末**调休上班**仍按空闲算（规则本身按"周末"判定，不看是否上班）。
  - 时区固定按 `Asia/Shanghai` 计算，与本机时区无关。
- **下次切换**：面板底部给出下一个峰/谷翻转时刻（`今天 12:00` / `明天 09:00` / `周一 09:00` / `10/8 09:00`），徽标上的 `距谷时 1h30m` 每秒刷新。
- **交互**：点击开关；`Esc` 或点击面板外关闭；`aria-expanded` / `role="dialog"` 已标注。
- **主题**：全部用宿主 `--dsw-alias-*` token，明/暗主题自动跟随；谷绿 `#059669`、峰橙 `#d97706` 只作用于圆点与高亮列。
- **文案**：中文/英文随界面语言切换（`ctx.locale` 字典 `dsPricing`）。

## 单价表（元 / 百万 tokens）

| 模型 | | 谷价 | 峰价 |
|---|---|---|---|
| `deepseek-flash` | 输入·缓存命中 | 0.02 | 0.04 |
| | 输入·缓存未命中 | 1 | 2 |
| | 输出 | 4 | 8 |
| `deepseek-v4-pro` | 输入·缓存命中 | 0.15 | 0.30 |
| | 输入·缓存未命中 | 4.5 | 9.0 |
| | 输出 | 13.5 | 27.0 |

来源：<https://api-docs.deepseek.com/zh-cn/quick_start/pricing/>（读取于 2026-11-09）。表里没有的 DeepSeek 模型显示 `—`，并提示以官方定价页为准。

## 数据来源

- **计费窗口**：DeepSeek API 文档「模型 & 价格」。
- **法定节假日**：国务院办公厅 2026 / 2027 年放假安排（`OFF_DAYS` 只收录落在**工作日**的假期日期 —— 周末本来就空闲，不必重复）。每年新通知发布后补 `client.js` 里的 `OFF_DAYS` 即可。

## 安装（别人怎么装）

**只把 `client.js` + `README.md` 拷过去是不行的** —— 插件是"双面包"，缺下面任何一个都装不上：`package.json`（声明双面与 slot 依赖）、`cordis.patch.yml`（host 组合里的 Loader 行）、`index.js`（host 半身）、`client.js`（浏览器半身）。再加上 profile 侧的两处登记和一个链接，共 5 件事。

一键版：

```bash
tar -xzf dsh-ds-pricing-1.0.0.tar.gz
node dsh-ds-pricing/install.mjs --dry-run   # 先看要做什么
node dsh-ds-pricing/install.mjs             # 自搬运 + 改 profile 清单 + 建链接
# 完全退出并重启 DSH
```

`install.mjs` 幂等、带备份（`package.json.bak-dsh-ds-pricing`），`--profile <名字>` 指定 profile，`--uninstall` 反向撤销；不需要 `npm install`，也不会联网。

手工版（本机已完成的就是这套）：

包目录：`~/.dsh/plugins/dsh-ds-pricing`，profile 侧接线：

1. `~/.dsh/profiles/desktop/package.json`
   - `dependencies`: `"dsh-ds-pricing": "file:../../plugins/dsh-ds-pricing"`
   - `dsh.profile.bundles`: 列表中加入 `dsh-ds-pricing`（顺序即 patch 层顺序）
2. `~/.dsh/profiles/desktop/node_modules/dsh-ds-pricing` → `../../../plugins/dsh-ds-pricing` 符号链接
3. 重启 DSH（新 bundle 需要重新读 profile 组合；浏览器刷新不够）

原 `package.json` 备份在 `~/.dsh/profiles/desktop/package.json.bak-ds-pricing`。

## 结构

| 文件 | 作用 |
|---|---|
| `package.json` | 清单：`dsh.bundle.patch` + `dsh.client`（`platform: web`, `immediately: true`, `inject: ["@deepseek-ai/dsh-client-ui-conversation"]`）+ `exports["./client"]` |
| `cordis.patch.yml` | 一行 `insert`，给 Host 组合加一个空插件行（客户端 bundle 需要一个活着的 Loader 条目） |
| `index.js` | Host 半身：空 `apply()`，只为提供 Loader 行 |
| `client.js` | 全部逻辑：北京时间、峰谷判定、下次切换、单价表、React 组件、样式、slot 注册 |
| `install.mjs` | 安装器：自搬运到 `$DSH_HOME/plugins/`、改 profile 清单、建 `node_modules` 链接（幂等，支持 `--dry-run` / `--uninstall` / `--profile`） |

手写 bundle，无构建步骤：`window.__ModuleLoader__.load({ id: 'dsh-ds-pricing', factory })`，`require('react')` 由 shell 的模块表提供。

## 常用改点

- **挂载位置**：`client.js` 末尾 `ctx.slots.inject('conversation.input.dock', …)`。旧版 DSH 若没有这个槽位（浏览器 console 报 `client-modules:`/slot 错误或干脆不出现），换成同族存在的 `conversation.composer.dock`（输入卡下方的统计区）即可，只改这一个字符串；`order: -100` 保证它排在其它 dock 项之上。
- **对齐方式**：`.dsp-root { width: min(var(--dsh-composer-card-max-width,760px), 100%); justify-content: flex-start }` —— 想右对齐改成 `flex-end`，想居中改 `center`。
- **新增模型单价**：往 `PRICES` 加一条，并在 `tableFor()` 加匹配（当前按模型名含 `pro` / `flash` / `chat` / `reasoner` 归类）。
- **新增/修正假期**：改 `OFF_DAYS`。

## 自测

纯函数与组件都能脱离宿主跑（jsdom + react-dom）：

```bash
export PATH=/Users/yangshuo/.local/node22/bin:$PATH   # 本机 node 不在 PATH
cd /tmp/dsptest && node test.mjs
# clock cases: 23 · switch cases: 6 · render cases: 6
# ALL PASS
```

测试覆盖 9:00/12:00/14:00/18:00 四个边界、周末、2026 调休日（9/20、10/10）、2026 春节/中秋/国庆、2027 元旦/春节、跨假期与跨年的下次切换、provider 识别（含"聚合插件不得冒领"）、未知模型占位，以及 6 个真实 DOM 渲染用例（含英文界面不出现中文）。`client.js` 末尾 `exports.__test` 是这些用例的入口。
